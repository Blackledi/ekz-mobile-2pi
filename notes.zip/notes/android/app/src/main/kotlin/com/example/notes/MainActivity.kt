package com.example.notes

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
